package com.example.anakha.resapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddRestaurant extends AppCompatActivity {
    Button btnSaveRes,btnView;
    EditText editPlace,editHotelName,editDes,editPhone;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_restaurant);
        btnSaveRes=(Button)findViewById(R.id.btnSaveRes);
        btnView=(Button)findViewById(R.id.btnView);
        editPlace=(EditText)findViewById(R.id.editPlace);
        editHotelName=(EditText)findViewById(R.id.editHotelName);
        editDes=(EditText)findViewById(R.id.editDes);
        editPhone=(EditText)findViewById(R.id.editPhone);
        btnSaveRes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add1();
            }
        });
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view1();
            }
        });
        db=openOrCreateDatabase("RestaurantDB2", Context.MODE_PRIVATE,null);
        if (db!=null){
            Toast.makeText(this,"Created", Toast.LENGTH_SHORT).show();
        }
        String query1="CREATE TABLE IF NOT EXISTS res(id INTEGER PRIMARY KEY AUTOINCREMENT,place VARCHAR,name VARCHAR,des VARCHAR,phone VARCHAR);";
        db.execSQL(query1);

    }
    public void add1(){
        if(editPlace.getText().toString().trim().length()==0||editHotelName.getText().toString().trim().length()==0||editDes.getText().toString().trim().length()==0||editPhone.getText().toString().trim().length()==0){
            showMessage("Error","Please Enter All Values");
            return;
        }
        db.execSQL("INSERT INTO res (place,name,des,phone) VALUES('"+editPlace.getText()+"','"+editHotelName.getText()+"','"+editDes.getText()+"','"+editPhone.getText()+"');");
        showMessage("Success","Record Added");
        clearText();
//        Intent inte= new Intent(AddRestaurant.this,Start.class);
//        startActivity(inte);


    }
    public void view1(){
        Cursor c=db.rawQuery("SELECT * FROM res", null);
        if(c.getCount()==0){
            showMessage("Error", "No records found");
            return;
        }
        StringBuffer buffer=new StringBuffer();
        while(c.moveToNext())    {
            buffer.append("Place: "+c.getString(1)+"\n");
            buffer.append("Hotel Name: "+c.getString(2)+"\n");
            buffer.append("Description: "+c.getString(3)+"\n");
            buffer.append("Phone: "+c.getString(4)+"\n\n");
        }
        showMessage("Employee details Details", buffer.toString());
    }





    public void showMessage(String title,String message){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText(){
        editPlace.setText("");
        editHotelName.setText("");
        editDes.setText("");
        editPhone.setText("");
    }

}
