package com.example.anakha.resapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListPlaces extends AppCompatActivity {
    SQLiteDatabase db;
    ListView lv;
    Context mContext;
    String nm;
    ArrayAdapter<String> ada;
    ArrayList<String> list=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_places);
        mContext = this;
        lv = (ListView) findViewById(R.id.listPlaces);
        db = openOrCreateDatabase("RestaurantDB2", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        }
        String query2 = "CREATE TABLE IF NOT EXISTS res(id INTEGER PRIMARY KEY AUTOINCREMENT,place VARCHAR,name VARCHAR,des VARCHAR,phone VARCHAR);";
        db.execSQL(query2);
        Cursor cur = db.rawQuery("SELECT DISTINCT(place) FROM res ORDER BY place ASC", null);
        if (cur.getCount() != 0) {
            cur.moveToFirst();
            int c = cur.getCount();
            for (int i = 0; i < c; i++) {
                nm = cur.getString((cur.getColumnIndex("place")));
                list.add(nm);
                cur.moveToNext();
            }
            ada = new ArrayAdapter<String>(mContext, android.R.layout.simple_list_item_1, list);
            lv.setAdapter(ada);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent in=new Intent(ListPlaces.this,HotelNames.class);
                    in.putExtra("place", (String) parent.getItemAtPosition(position));
                    //Toast.makeText(getApplicationContext(),(String) parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                    startActivity(in);
                }
            });
        }
    }
}
