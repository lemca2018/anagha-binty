package com.example.anakha.resapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Start extends AppCompatActivity {
    Button btnStart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        btnStart=(Button)findViewById(R.id.btnStart);
       // btnAdd=(Button)findViewById(R.id.btnAdd);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2=new Intent(Start.this,ListPlaces.class);
                startActivity(int2);
            }
        });
//        btnAdd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent int1=new Intent(Start.this,AddRestaurant.class);
//                startActivity(int1);
//            }
//        });
    }

}
