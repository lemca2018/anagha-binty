package com.example.anakha.resapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class HotelInfo extends AppCompatActivity {
    TextView e1,e2,e3,e4;
    SQLiteDatabase db;
    Context mc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_info);
        e1=(TextView)findViewById(R.id.Hname);
        e2=(TextView)findViewById(R.id.HPlace);
        e3=(TextView)findViewById(R.id.HPhno);
        e4=(TextView)findViewById(R.id.HDes);

        mc = this;
        Intent in=getIntent();
        String vnm=in.getStringExtra("name");

        db = openOrCreateDatabase("RestaurantDB2", Context.MODE_PRIVATE, null);
        String query3 = "CREATE TABLE IF NOT EXISTS res(id INTEGER PRIMARY KEY AUTOINCREMENT,place VARCHAR,name VARCHAR,des VARCHAR,phone VARCHAR);";
        db.execSQL(query3);
        Cursor cur3 = db.rawQuery("SELECT * FROM res where name='"+vnm+"'", null);

        cur3.moveToFirst();

        String num=cur3.getString(cur3.getColumnIndex("name"));
        String name=cur3.getString(cur3.getColumnIndex("place"));
        String sr=cur3.getString(cur3.getColumnIndex("phone"));
        String dn=cur3.getString(cur3.getColumnIndex("des"));

//        Toast.makeText(mc,"passed"+mid,Toast.LENGTH_LONG).show();

        e1.setText(num);
        e2.setText(name);
        e3.setText(sr);
        e4.setText(dn);
    }
}

