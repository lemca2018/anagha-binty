package com.example.anakha.resapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class HotelNames extends AppCompatActivity {
    SQLiteDatabase db;
    ListView lv1;
    Context mContext;
    String nm;
    ArrayAdapter<String> ada;
    ArrayList<String> list=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_names);
        mContext = this;
        Intent in=getIntent();
        String vnm=in.getStringExtra("place");
        lv1 = (ListView) findViewById(R.id.listHotels);
        db = openOrCreateDatabase("RestaurantDB2", Context.MODE_PRIVATE, null);
        String query3 = "CREATE TABLE IF NOT EXISTS res(id INTEGER PRIMARY KEY AUTOINCREMENT,place VARCHAR,name VARCHAR,des VARCHAR,phone VARCHAR);";
        db.execSQL(query3);
        Cursor cur = db.rawQuery("SELECT * FROM res where place='"+vnm+"' ORDER BY name ASC", null);
        if (cur.getCount() != 0) {
            cur.moveToFirst();
            int c = cur.getCount();
            for (int i = 0; i < c; i++) {
                nm = cur.getString((cur.getColumnIndex("name")));
                list.add(nm);
                cur.moveToNext();
            }
            ada = new ArrayAdapter<String>(mContext, android.R.layout.simple_list_item_1, list);
            lv1.setAdapter(ada);
            lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent in = new Intent(HotelNames.this,HotelInfo.class);
                    in.putExtra("name", (String) parent.getItemAtPosition(position));
                    //Toast.makeText(getApplicationContext(),(String) parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                    startActivity(in);
                }
            });
        }
    }

}
